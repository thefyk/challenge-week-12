# 425248.csv

PERIOD OF REQUEST
Start Date:	2010 -01-01
End Date:	2010 -12-31
REQUESTED DATA
Custom Options:	Station name, Geographic location, Include data flags
Locations:	CITY:US040011 - Phoenix, AZ US
CITY:US320004 - Las Vegas, NV US
CITY:US550006 - Madison, WI US
Data Types:	HPCP - Precipitation (100th of an inch)
